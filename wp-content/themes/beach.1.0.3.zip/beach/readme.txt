== Changelog ==

= 1.0.3 - Oct 4 2011 =
* the_post should always be called in the loop
* Make sure the current category highlights in the menu
* Set svn:eol-style on JS and TXT files
* Fix get_the_author() escaping
* Move functions from comments.php to functions.php to avoid redeclaration errors
* Trim whitespace and fix CSS formatting